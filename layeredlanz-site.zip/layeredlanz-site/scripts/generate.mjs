#!/usr/bin/env node
// Fetches this shop's live Etsy listings via the Etsy Open API v3 and
// regenerates index.html from template.html + config.json.
//
// Requires Node 18+ (uses the built-in fetch).
// Requires env var ETSY_API_KEY (a free API key from developer.etsy.com).
// Optional env var SHOP_NAME (defaults to "LayeredLanz").

import { readFile, writeFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import path from "node:path";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, "..");

const API_KEY = process.env.ETSY_API_KEY;
const SHOP_NAME = process.env.SHOP_NAME || "LayeredLanz";
const BASE = "https://openapi.etsy.com/v3/application";

if (!API_KEY) {
  console.error("Missing ETSY_API_KEY environment variable. Get a free key at https://www.etsy.com/developers/register");
  process.exit(1);
}

async function etsyGet(pathAndQuery) {
  const res = await fetch(`${BASE}${pathAndQuery}`, {
    headers: { "x-api-key": API_KEY },
  });
  if (!res.ok) {
    const body = await res.text().catch(() => "");
    throw new Error(`Etsy API ${res.status} on ${pathAndQuery}: ${body}`);
  }
  return res.json();
}

function money(price) {
  const amount = price.amount / price.divisor;
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: price.currency_code || "USD",
  }).format(amount);
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

async function main() {
  const config = JSON.parse(await readFile(path.join(ROOT, "config.json"), "utf8"));

  // 1. Find the shop by name to get its numeric shop_id.
  const shopSearch = await etsyGet(`/shops?shop_name=${encodeURIComponent(SHOP_NAME)}`);
  const shop = shopSearch.results?.[0];
  if (!shop) {
    throw new Error(`No Etsy shop found for shop_name="${SHOP_NAME}". Check the SHOP_NAME env var / spelling.`);
  }
  const shopId = shop.shop_id;

  // 2. Shop sections, so items can be tagged the way you've organized them on Etsy.
  const sectionsRes = await etsyGet(`/shops/${shopId}/sections`);
  const sectionsById = new Map((sectionsRes.results || []).map((s) => [s.shop_section_id, s.title]));

  // 3. All active (for-sale) listings, with their photos included.
  const listingsRes = await etsyGet(`/shops/${shopId}/listings/active?limit=100&includes=Images`);
  const listings = listingsRes.results || [];

  if (listings.length === 0) {
    // Refuse to publish an empty shop page — better to leave the last good
    // build in place than overwrite it with nothing (e.g. a transient API
    // hiccup, a temporarily-empty shop, or a bad request).
    throw new Error("Etsy returned zero active listings — aborting so the live site isn't overwritten with an empty page.");
  }

  // 4. Build one card per listing.
  const cards = listings
    .map((listing) => {
      const img = listing.images?.[0]?.url_fullxfull || listing.images?.[0]?.url_570xN || "";
      const tag = sectionsById.get(listing.shop_section_id) || "Shop item";
      const title = escapeHtml(listing.title);
      const price = money(listing.price);
      const url = (listing.url || "").split("?")[0];
      return `      <article class="card">
        <div class="card-media">
          <span class="tag">${escapeHtml(tag)}</span>
          <img src="${img}" alt="${title}" loading="lazy">
        </div>
        <div class="card-body">
          <h3 class="card-title">${title}</h3>
          <div class="card-foot">
            <span class="price">${price}</span>
            <a class="buy-btn" href="${url}" target="_blank" rel="noopener noreferrer">Buy on Etsy ↗</a>
          </div>
        </div>
      </article>`;
    })
    .join("\n");

  // 5. Stat strip: total items, year the shop opened, plus up to two of the
  //    shop's own sections (so this adapts if sections are renamed/added).
  const sectionCounts = new Map();
  for (const listing of listings) {
    const tag = sectionsById.get(listing.shop_section_id) || "Uncategorized";
    sectionCounts.set(tag, (sectionCounts.get(tag) || 0) + 1);
  }
  const sinceYear = shop.create_date ? new Date(shop.create_date * 1000).getFullYear() : new Date().getFullYear();

  const statTiles = [
    `    <div class="stat"><span class="num mono">${listings.length}</span><span class="label">Items in shop</span></div>`,
    `    <div class="stat"><span class="num mono">${sinceYear}</span><span class="label">On Etsy since</span></div>`,
    ...[...sectionCounts.entries()]
      .slice(0, 2)
      .map(([name, count]) => `    <div class="stat"><span class="num mono">${count}</span><span class="label">${escapeHtml(name)}</span></div>`),
  ].join("\n");

  // 6. Policy cards come from config.json (Etsy's public API doesn't expose
  //    the free-text policy fields), edit that file by hand if these change.
  const policyCards = config.policies
    .map((p) => `      <div class="policy-card"><h3>${escapeHtml(p.title)}</h3><p>${escapeHtml(p.body)}</p></div>`)
    .join("\n");

  // 7. Fill in the template.
  let html = await readFile(path.join(ROOT, "template.html"), "utf8");
  const shopDisplayName = shop.shop_name || SHOP_NAME;
  const replacements = {
    "{{SHOP_NAME_UPPER}}": escapeHtml(shopDisplayName.toUpperCase()),
    "{{SHOP_NAME}}": escapeHtml(shopDisplayName),
    "{{SHOP_URL}}": `https://www.etsy.com/shop/${encodeURIComponent(SHOP_NAME)}`,
    "{{CONTACT_URL}}": config.contactUrl,
    "{{ITEM_CARDS}}": cards,
    "{{STAT_TILES}}": statTiles,
    "{{STORY}}": escapeHtml(config.storyQuote),
    "{{POLICY_CARDS}}": policyCards,
    "{{UPDATED_AT}}": new Date().toISOString().slice(0, 10),
  };
  for (const [key, value] of Object.entries(replacements)) {
    html = html.split(key).join(value);
  }

  await writeFile(path.join(ROOT, "index.html"), html, "utf8");
  console.log(`Wrote index.html with ${listings.length} listings from ${shopDisplayName}.`);
}

main().catch((err) => {
  console.error(err.message || err);
  process.exit(1);
});
